# Get the IP address
ip=$(getent hosts internal.example.com | awk '{ print $1 }')

# Check HTTP connectivity
curl -Iv http://$ip
curl -Iv http://internal.example.com

# Check HTTPS connectivity
curl -Iv https://$ip
curl -Iv https://internal.example.com

# Check port connectivity
telnet $ip 80
telnet $ip 443

# Check if service is listening locally (if applicable)
netstat -tulnp | grep ':80\|:443'
ss -tulnp | grep ':80\|:443'