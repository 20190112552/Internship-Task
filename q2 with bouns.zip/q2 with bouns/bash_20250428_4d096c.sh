nmcli connection modify <connection-name> ipv4.dns "192.168.1.1 8.8.8.8"
nmcli connection up <connection-name>