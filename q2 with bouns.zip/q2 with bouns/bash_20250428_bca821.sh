sudo systemctl enable --now systemd-resolved
sudo resolvectl dns <interface> 192.168.1.1 8.8.8.8